package testcases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wdMethods.SeMethod;

public class Login extends SeMethod{

	@Test
	public void login() {
		startApp("chrome", "http://leafTaps.com/opentaps");
		WebElement eleuserName = locateElement("id", "username");
		type(eleuserName, "DemoCSR");
		WebElement elepassword = locateElement("id", "password");
		type(elepassword, "crmsfa");
		WebElement eleLogin = locateElement("class","decorativeSubmit");
		click(eleLogin);
	}

}








