package pages;

import org.openqa.selenium.WebElement;

import wdMethods.ProjectMethods;

public class HomePage extends ProjectMethods{

	
	
	public LoginPage clickLogOut() {
		WebElement eleLogOut = locateElement("class", "decorativeSubmit");
	    click(eleLogOut);  
	    return new LoginPage();
	}
	
}







